package charles.corejava;

import java.util.ArrayList;
import java.util.List;

public class ContactBusiness {
	
	public List<Contact> getContactList(){
		List<Contact> listContact=new ArrayList<>();
		listContact.add(new Contact("Jon Snow","jon.snow@gmail.com", "WINTERFELL"));
		listContact.add(new Contact("Jamie Lannister","jamie.lannister@msn.com","CASTERLY ROCK"));
		listContact.add(new Contact("Authur Dayne" , "authur.dayne@yahoo.com","STARFELL"));
		listContact.add(new Contact("Robert Baratheon","robert.baratheon@live.com","STORMS-END"));
		
		return listContact;
	}

}
